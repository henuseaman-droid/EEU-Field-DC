# EEU Field Collector - Android Project
This project was generated for Ethiopian Electric Utility (EEU / የኢትዮጵያ ኤሌክትሪክ አገልግሎት).

## Option A: Direct Android APK Build using Bubblewrap CLI
```bash
npm install -g @bubblewrap/cli
bubblewrap init --manifest="https://ais-pre-5zfhndkit3qogt7bb54dlb-74829770697.europe-west2.run.app/manifest.webmanifest"
bubblewrap build
```
This produces an `app-release-signed.apk` ready to install on any Android phone.

## Option B: Android Studio Build
1. Open this directory in Android Studio.
2. Build > Build Bundle(s) / APK(s) > Build APK(s).
3. Transfer `app-debug.apk` to your Android phone and install.
